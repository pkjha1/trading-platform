from django.apps import AppConfig


class KiwoomConfig(AppConfig):
    name = 'kiwoom'
